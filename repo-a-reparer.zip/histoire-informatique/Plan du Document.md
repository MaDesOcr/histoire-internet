# Plan
1. Precurseurs
2. Fondements theoriques
3. Premiers ordinateurs
4. Micro-informatique
6. Conclusion
