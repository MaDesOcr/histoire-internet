# Premiers ordinateurs

<<<<<<< HEAD
L'ENIAC (1945) utilisait des tubes a vide.
=======
Le transistor (1947) a remplace les tubes a vide.
>>>>>>> brouillon

Le circuit integre arrive en 1958.
