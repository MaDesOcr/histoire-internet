# Les precurseurs
La Pascaline (1642), Jacquard (1801), Babbage et Lovelace.
