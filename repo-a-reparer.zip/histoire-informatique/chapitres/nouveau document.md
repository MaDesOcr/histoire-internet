# Theorie
Boole, Turing, Shannon, von Neumann.
